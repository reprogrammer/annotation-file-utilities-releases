
package annotations;


public enum ValuesEnum {
  ONE, TWO, THREE;
}
