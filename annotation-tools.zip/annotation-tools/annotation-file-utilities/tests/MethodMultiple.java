package annotator.tests;

public class MethodMultiple {
  public String foo() {
    return null;
  }
  
  public String foo(String s) {
    return null;
  }
}
