package annotator.tests;

public class EnumListAnnotationParameter {
  public void foo() {
  }
}