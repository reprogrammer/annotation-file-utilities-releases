package annotator.tests;

import java.util.Date;

public class ClassSimple {
  public Integer field;
}
