package annotator.tests;

public class DeclarationAnnotation {
  public void foo() {
  }
}
