package annotator.tests;

import java.util.List;

public class ConstructorParam {
  public ConstructorParam(int paramB) {

  }
}
