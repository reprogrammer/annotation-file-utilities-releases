package annotator.tests;

public class NewSimple {
  public void foo() {
    Object o = new Object();
    System.out.println(o);
  }
}
