package annotator.tests;

import java.util.*;

public class GenericMultiLevel {
  Map<Comparable<Object>, List<Date>> field;
}
