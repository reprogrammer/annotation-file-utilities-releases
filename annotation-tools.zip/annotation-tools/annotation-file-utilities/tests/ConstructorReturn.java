package annotator.tests;

class ConstructorReturn {
   public ConstructorReturn() { }
}

