package annotator.tests;

public class FieldNew {
  Object f = new FieldNew();
}
