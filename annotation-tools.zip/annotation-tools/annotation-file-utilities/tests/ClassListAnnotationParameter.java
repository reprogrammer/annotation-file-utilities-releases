package annotator.tests;

public class ClassListAnnotationParameter {
  public void foo() {
  }
}