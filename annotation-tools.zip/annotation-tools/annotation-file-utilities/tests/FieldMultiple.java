package annotator.tests;

public class FieldMultiple {
  public Integer foo;
  public Integer d;
}
