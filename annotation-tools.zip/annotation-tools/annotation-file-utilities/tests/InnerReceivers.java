public class InnerReceivers {

    InnerReceivers i = new InnerReceivers() {

        void m() {}
    };
}
