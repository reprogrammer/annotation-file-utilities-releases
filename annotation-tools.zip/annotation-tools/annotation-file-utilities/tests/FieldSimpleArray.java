package annotator.tests;

public class FieldSimpleArray {
  Integer[] field;
}
