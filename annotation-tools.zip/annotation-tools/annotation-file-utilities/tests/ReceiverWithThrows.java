package annotator.tests;

public class ReceiverWithThrows {
  /* @Mutable ReceiverWithThrows this */
  public void foo() {

  }

  /* @ReadOnly ReceiverWithThrows this */
  public void bar() throws Exception {

  }
}
