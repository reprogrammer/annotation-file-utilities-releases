package pkg.name.here;

class Package {
    Object o;
}
