package annotator.tests;

import java.util.*;

public class InnerTypeResolution {
    Map.Entry method01(Map m){
        return null;
    }
}

