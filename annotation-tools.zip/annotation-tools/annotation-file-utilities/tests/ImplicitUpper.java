class ExplicitUpper<X extends Object> {
}

public class ImplicitUpper<Y> {
}
