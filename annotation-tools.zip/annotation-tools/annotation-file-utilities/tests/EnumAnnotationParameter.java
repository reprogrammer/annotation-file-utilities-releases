package annotator.tests;

public class EnumAnnotationParameter {
  public void foo() {
  }
}