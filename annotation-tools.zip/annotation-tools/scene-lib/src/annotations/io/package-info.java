/**
 * <code>annotations.io</code> provides classes for the input and output
 * of {@link annotations.el.AScene}s to/from various formats.
 */
package annotations.io;

