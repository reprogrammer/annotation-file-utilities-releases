package annotations.tests.classfile.cases;

public class TestFieldSimple {
  public int i;
  private int j;
  protected Object o;
  String s = null;
  TestFieldSimple f = null;
}
