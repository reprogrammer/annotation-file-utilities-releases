package annotations.toys;

public @interface SubAnnotation {
    int[] value();
}
