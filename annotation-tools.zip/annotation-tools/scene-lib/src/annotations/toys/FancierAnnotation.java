package annotations.toys;

public @interface FancierAnnotation {
    FancyAnnotation fa();
}
