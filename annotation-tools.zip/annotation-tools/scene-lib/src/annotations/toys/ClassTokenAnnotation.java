package annotations.toys;

public @interface ClassTokenAnnotation {
    Class<?>[] favoriteClasses();
}
