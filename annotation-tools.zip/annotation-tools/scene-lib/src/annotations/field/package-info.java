/**
 * <code>annotations.field</code> provides classes that store the types of
 * annotation fields.
 */
package annotations.field;

